 Buddy Racer is right back on track. 
 Take part in this realistic motorcycle physics controlling and bike maneuvering game, be the best racer and get the highest score.
 Launch off an enormous jump, land on your rear wheel and make your way through a variety of obstacles. Pass obstacles that  racing track has to offer and make sure not to flip the bike around. Your reflexes will mean the difference between      surviving or failing in spectacular fashion.
 Hold down left mouse button or touch screen to accelerate.
 Enjoy unmatched physics engine that gives you a mind boggling level of control and amazing vector graphics that are perfectly optimized for tablets and high-resolution devices.
 Start your engine, rush at full speed and have fun!
 
Browser game - http://buddyracer.publicgamelibrary.com/

Chrome Web app - https://chrome.google.com/webstore/detail/buddy-racer/plnkfkpbgjpmgfjkpepkkdbiakiicfnn

Android APK file (including Java wrapper with Admob Banner and Interstitial Ads and Google Analytics Integration) - https://play.google.com/store/apps/details?id=com.publicgamelibrary.buddyracer

Firefox packaged app (hosted version is also available) https://marketplace.firefox.com/app/buddy-racer

Well documented source files are provided for each one of the formats.
